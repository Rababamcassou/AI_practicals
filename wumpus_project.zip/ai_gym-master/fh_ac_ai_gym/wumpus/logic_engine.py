class CNFResolver:
    def __init__(self):
        self.clauses = set()

    def tell(self, sentence):
        """
        Fügt eine neue Klausel zur Wissensbasis hinzu.
        sentence: list[str] oder set[str], z. B. ['A', '-B']
        """
        if isinstance(sentence, str):
            clause = frozenset([sentence])
        else:
            clause = frozenset(sentence)
        self.clauses.add(clause)

    def ask(self, query):
        """
        Prüft, ob die gegebene Aussage aus der KB ableitbar ist.
        query: str, z. B. 'A'
        """
        return self.query(query)

    def add_clause(self, clause):
        """Veraltete Methode – nutze stattdessen TELL."""
        self.tell(clause)

    def query(self, query):
        """
        Resolution auf Negation der Anfrage (¬query) mit der KB.
        """
        new_clauses = self.clauses.copy()
        negated_query = frozenset({self._negate(query)})
        new_clauses.add(negated_query)

        while True:
            new = set()
            pairs = [(c1, c2) for c1 in new_clauses for c2 in new_clauses if c1 != c2]
            for (ci, cj) in pairs:
                resolvents = self.resolve(ci, cj)
                for r in resolvents:
                    if not r:
                        return True  # Leere Klausel ⇒ Beweis
                    new.add(frozenset(r))
            if new.issubset(new_clauses):
                return False  # Nichts Neues ⇒ nicht ableitbar
            new_clauses.update(new)

    def resolve(self, ci, cj):
        resolvents = []
        for di in ci:
            for dj in cj:
                if di == self._negate(dj):
                    new_clause = (ci - {di}) | (cj - {dj})
                    resolvents.append(new_clause)
        return resolvents

    def _negate(self, literal):
        return literal[1:] if literal.startswith('-') else '-' + literal

class HornClause:
    def __init__(self, premises, conclusion):
        self.premises = premises
        self.conclusion = conclusion

class HornKB:
    def __init__(self):
        self.clauses = []
        self.facts = set()

    def tell(self, clause):
        if isinstance(clause, HornClause):
            # Direkte HornClause
            self.clauses.append(clause)
            if not clause.premises:
                self.facts.add(clause.conclusion)
            return

        if isinstance(clause, str):
            clause = clause.strip()
            if '=>' in clause:
                body, head = clause.split('=>')
                body_literals = [b.strip() for b in body.split('&') if b.strip()]
                head = head.strip()
                self.clauses.append(HornClause(body_literals, head))
            else:
                self.facts.add(clause)
            return

        if isinstance(clause, set) or isinstance(clause, frozenset):
            # Falls aus Versehen ein CNF-Satz übergeben wurde: Ignorieren oder warnen
            print(f"[WARNUNG] Set als Horn-Klausel erkannt (nicht gültig): {clause}")
            return

        raise ValueError(f"Unsupported clause type: {type(clause)}")

    def ask(self, query):
        inferred = set(self.facts)
        changed = True
        while changed:
            changed = False
            for clause in self.clauses:
                if set(clause.premises).issubset(inferred) and clause.conclusion not in inferred:
                    inferred.add(clause.conclusion)
                    changed = True
        return query in inferred



class WumpusLogicConnector:
    def __init__(self, logic_engine):
        self.kb = logic_engine
        self.visited = set()

        if isinstance(logic_engine, CNFResolver):
            self.add_cnf_rules()
        elif isinstance(logic_engine, HornKB):
            self.kb.clauses = []  # Initialisiere Horn-Klauseln
            self.add_wumpus_rules()

    def add_cnf_rules(self):
        width, height = 4, 4
        for x in range(width):
            for y in range(height):
                neighbors = self.get_adjacent(x, y)

                # Stench → Wumpus-Nachbar / Wumpus-Nachbar → Stench
                for nx, ny in neighbors:
                    self.kb.tell({f"-S{x}{y}", f"W{nx}{ny}"})
                    self.kb.tell({f"-W{nx}{ny}", f"S{x}{y}"})

                # Breeze → Pit-Nachbar / Pit-Nachbar → Breeze
                for nx, ny in neighbors:
                    self.kb.tell({f"-B{x}{y}", f"P{nx}{ny}"})
                    self.kb.tell({f"-P{nx}{ny}", f"B{x}{y}"})

                # Breeze → mindestens ein Nachbar Pit (konjunktive Normalform)
                pit_literals = {f"P{nx}{ny}" for nx, ny in neighbors}
                pit_literals.add(f"-B{x}{y}")
                self.kb.tell(pit_literals)

                # Erweiterte Regel: wenn Bxy und alle außer einem Nachbarn sind ¬P, dann letzter muss P sein
                for excluded in neighbors:
                    known_safe = [n for n in neighbors if n != excluded]
                    clause = {f"-B{x}{y}", f"P{excluded[0]}{excluded[1]}"}
                    for sx, sy in known_safe:
                        clause.add(f"-P{sx}{sy}")
                    self.kb.tell(clause)

                # Entsprechendes für Stench/Wumpus
                wumpus_literals = {f"W{nx}{ny}" for nx, ny in neighbors}
                wumpus_literals.add(f"-S{x}{y}")
                self.kb.tell(wumpus_literals)

                for excluded in neighbors:
                    known_safe = [n for n in neighbors if n != excluded]
                    clause = {f"-S{x}{y}", f"W{excluded[0]}{excluded[1]}"}
                    for sx, sy in known_safe:
                        clause.add(f"-W{sx}{sy}")
                    self.kb.tell(clause)

    def add_wumpus_rules(self):
        width, height = 4, 4
        for x in range(width):
            for y in range(height):
                neighbors = self.get_adjacent(x, y)

                # Lokale Regeln für jedes Nachbarfeld
                for nx, ny in neighbors:
                    self.kb.tell(HornClause([f"B{nx}_{ny}"], f"P{x}_{y}"))
                    self.kb.tell(HornClause([f"-B{x}_{y}"], f"-P{nx}_{ny}"))
                    self.kb.tell(HornClause([f"S{nx}_{ny}"], f"W{x}_{y}"))
                    self.kb.tell(HornClause([f"-S{x}_{y}"], f"-W{nx}_{ny}"))

                # Breeze → mindestens ein Nachbar hat Pit (nicht direkt in Horn ableitbar, aber nur umgekehrt geht)
                # Erweiterte Regel: Wenn Bxy und alle bis auf einen Nachbarn sind sicher → letzter hat Pit
                for excluded in neighbors:
                    known_safe = [n for n in neighbors if n != excluded]
                    premises = [f"B{x}_{y}"] + [f"-P{sx}_{sy}" for sx, sy in known_safe]
                    conclusion = f"P{excluded[0]}_{excluded[1]}"
                    self.kb.tell(HornClause(premises, conclusion))

                # Analog: Stench → Wumpus
                for excluded in neighbors:
                    known_safe = [n for n in neighbors if n != excluded]
                    premises = [f"S{x}_{y}"] + [f"-W{sx}_{sy}" for sx, sy in known_safe]
                    conclusion = f"W{excluded[0]}_{excluded[1]}"
                    self.kb.tell(HornClause(premises, conclusion))

    def update_kb_from_percepts(self, percepts, x, y):
        loc = f"{x}{y}"
        self.visited.add((x, y))

        if isinstance(self.kb, CNFResolver):
            if percepts.breeze:
                neighbors = self.get_adjacent(x, y)
                clause = {f"P{nx}{ny}" for nx, ny in neighbors}
                clause.add(f"-B{x}{y}")
                self.kb.tell(clause)
            else:
                for nx, ny in self.get_adjacent(x, y):
                    self.kb.tell({f"-P{nx}{ny}"})

            if percepts.stench:
                clause = {f"W{nx}{ny}" for nx, ny in self.get_adjacent(x, y)}
                self.kb.tell(clause)
            else:
                for nx, ny in self.get_adjacent(x, y):
                    self.kb.tell({f"-W{nx}{ny}"})

            if percepts.glitter:
                self.kb.tell({f"G{loc}"})
            else:
                self.kb.tell({f"-G{loc}"})

        elif isinstance(self.kb, HornKB):
            if percepts.breeze:
                self.kb.tell(HornClause([], f"B{loc}"))
            else:
                self.kb.tell(HornClause([], f"-B{loc}"))

            if percepts.stench:
                self.kb.tell(HornClause([], f"S{loc}"))
            else:
                self.kb.tell(HornClause([], f"-S{loc}"))

            if percepts.glitter:
                self.kb.tell(HornClause([], f"G{loc}"))
            else:
                self.kb.tell(HornClause([], f"-G{loc}"))

    def is_safe(self, x, y):
        if isinstance(self.kb, CNFResolver):
            return self.kb.query(f"-P{x}{y}") and self.kb.query(f"-W{x}{y}")
        elif isinstance(self.kb, HornKB):
            return self.kb.ask(f"-P{x}_{y}") and self.kb.ask(f"-W{x}_{y}")

    def is_pit(self, x, y):
        if isinstance(self.kb, CNFResolver):
            return self.kb.query(f"P{x}{y}")
        elif isinstance(self.kb, HornKB):
            return self.kb.ask(f"P{x}_{y}")

    def get_adjacent(self, x, y):
        neighbors = []
        if x > 0: neighbors.append((x - 1, y))
        if x < 3: neighbors.append((x + 1, y))
        if y > 0: neighbors.append((x, y - 1))
        if y < 3: neighbors.append((x, y + 1))
        return neighbors



class LogicManager:
    def __init__(self, mode="CNF"):
        if mode == "CNF":
            self.kb = CNFResolver()
            self.mode = "CNF"
        else:
            self.kb = HornKB()
            self.mode = "HORN"

    def tell(self, clause):
            self.kb.tell(clause)

    def ask(self, query):
            return self.kb.ask(query)