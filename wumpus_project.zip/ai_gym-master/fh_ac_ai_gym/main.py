from fh_ac_ai_gym.wumpus.logic_engine import CNFResolver, HornKB
from fh_ac_ai_gym.wumpus.WumpusWorld import Wumpus_World
from fh_ac_ai_gym.wumpus.WorldState import Action, Location, Direction

def run_safe_agent():
    world = Wumpus_World(size=4)

    # Manuelle Initialisierung der Welt
    world.state.wumpus_location = Location(1, 0)
    world.state.pit_locations = [Location(1, 2)]
    world.state.gold_location = Location(3, 3)
    world.state.agent_location = Location(0, 0)
    world.state.agent_direction = Direction.NORTH

    print("Initiale Welt:")
    world.print()

    def move_to(direction):
        world.state.agent_direction = direction
        world.exec_action(Action.WALK)
        world.print()
        percept = world.percept
        loc = world.state.agent_location
        print(f"Wahrnehmung bei {loc}: {percept}")
        world.update_kb_from_perception(percept, loc)

    # 1. Startposition analysieren (0,0)
    print("Schritt 1: Start (0,0)")
    world.update_kb_from_perception(world.percept, world.state.agent_location)

    # 2. nach Norden zu (0,1)
    print("Schritt 2: nach Norden (0,1)")
    move_to(Direction.NORTH)

    # 3. nach Norden zu (0,2)
    print("Schritt 3: nach Norden (0,2)")
    move_to(Direction.NORTH)

    # 4. nach Osten zu (1,2) - wird ausgelassen (Pit), daher nach Osten zu (1,3)
    print("Schritt 4: nach Norden (0,3)")
    move_to(Direction.NORTH)

    print("Schritt 5: nach Osten (1,3)")
    move_to(Direction.EAST)

    print("Schritt 6: nach Osten (2,3)")
    move_to(Direction.EAST)

    print("Schritt 7: nach Süden (2,2)")
    move_to(Direction.SOUTH)

    print("Schritt 8: nach Süden (2,1)")
    move_to(Direction.SOUTH)

    print("Schritt 9: nach Westen (1,1)")
    move_to(Direction.WEST)

    print("Schritt 10: nach Westen (0,1)")
    move_to(Direction.WEST)

    print("Schritt 11: nach Norden (0,2)")
    move_to(Direction.NORTH)

    print("Erneute Analyse: Ist (1,2) eine Grube?")
    print("CNF-Resolver:", world.kb.query("P12"))
    print("Horn-KB:", world.horn_kb.ask("P1_2"))

if __name__ == "__main__":
    run_safe_agent()
